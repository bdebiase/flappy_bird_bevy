use bevy::{app::PluginGroupBuilder, prelude::*, render::camera::ScalingMode};
use bevy_asset_loader::loading_state::{LoadingState, LoadingStateAppExt};

use crate::{
    anchor::AnchorPlugin,
    background::BackgroundPlugin,
    ground::GroundPlugin,
    physics::{Gravity, PhysicsPlugin},
    pipes::PipesPlugin,
    player::{Player, PlayerPlugin},
    tiling::TilingPlugin, ui::GameUiPlugin,
};

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Hash, States)]
pub enum GameState {
    #[default]
    Loading,
    Idling,
    Playing,
    Dead,
}

#[derive(Resource, Deref, DerefMut)]
pub struct DistanceTraveled(pub f32);

#[derive(Resource, Deref, DerefMut)]
pub struct GameScore(i32);

#[derive(Resource, Deref, DerefMut)]
pub struct GameSpeed(f32);

#[derive(Resource, Default, Deref, DerefMut)]
pub struct GameBoundaries(Rect);

pub struct GamePlugins;

impl PluginGroup for GamePlugins {
    fn build(self) -> PluginGroupBuilder {
        PluginGroupBuilder::start::<Self>()
            .add(AnchorPlugin)
            .add(TilingPlugin)
            .add(PhysicsPlugin)
            .add(GamePlugin)
            .add(GameUiPlugin)
            .add(BackgroundPlugin)
            .add(GroundPlugin)
            .add(PlayerPlugin)
            .add(PipesPlugin)
    }
}

pub struct GamePlugin;

impl Plugin for GamePlugin {
    fn build(&self, app: &mut App) {
        app.add_state::<GameState>()
            .add_loading_state(
                LoadingState::new(GameState::Loading).continue_to_state(GameState::Idling),
            )
            .insert_resource(ClearColor(Color::hex("#4EC0CA").unwrap()))
            .insert_resource(Gravity::from(-Vec2::Y * 400.0))
            .insert_resource(GameScore(0))
            .insert_resource(GameSpeed(50.0))
            .insert_resource(DistanceTraveled(0.0))
            .insert_resource(GameBoundaries::default())
            .add_systems(Startup, setup)
            .add_systems(OnEnter(GameState::Idling), restart)
            .add_systems(PreUpdate, update_boundaries)
            .add_systems(PreUpdate, update_distance)
            .add_systems(PreUpdate, update_camera);
    }
}

fn setup(mut commands: Commands) {
    let mut camera_bundle = Camera2dBundle::default();
    camera_bundle.projection.scale *= 0.25;
    camera_bundle.transform.translation.x += 50.0;
    commands.spawn(camera_bundle);
}

fn restart(
    mut distance_traveled: ResMut<DistanceTraveled>,
    mut game_score: ResMut<GameScore>,
) {
    **distance_traveled = 0.0;
    **game_score = 0;
}

fn update_distance(
    mut distance_traveled: ResMut<DistanceTraveled>,
    game_state: Res<State<GameState>>,
    game_speed: Res<GameSpeed>,
    time: Res<Time>,
) {
    if *game_state == GameState::Dead {
        return;
    }
    **distance_traveled += game_speed.0 * time.delta_seconds();
}

fn update_boundaries(
    mut game_boundaries: ResMut<GameBoundaries>,
    camera_query: Query<(&Transform, &OrthographicProjection)>,
) {
    let (transform, projection) = camera_query.single();
    let view_extents = Vec2::new(projection.area.width(), projection.area.height()) * 0.5
        + transform.translation.truncate();
    let game_height = 200.0;
    game_boundaries.min = Vec2::new(-view_extents.x * 1.25, -50.0);
    game_boundaries.max = Vec2::new(view_extents.x * 1.25, game_boundaries.min.y + game_height);
    // max: Vec2::new(view_extents.x * 1.25, view_extents.y - 20.0),
}

fn update_camera(
    mut query: Query<(&mut Transform, &OrthographicProjection), With<Camera>>,
    player_query: Query<&Transform, (With<Player>, Without<Camera>)>,
    game_boundaries: Res<GameBoundaries>,
) {
    query.for_each_mut(|(mut transform, projection)| {
        let width = game_boundaries.max.x * 0.5 - game_boundaries.min.x * 0.5;
        transform.translation.x = width * 0.25;

        player_query.for_each(|player_transform| {
            let min_clamp = game_boundaries.min.y + projection.area.half_size().y * 0.5;
            let max_clamp = game_boundaries.max.y - projection.area.half_size().y;
            
            // if projection.area.size().y  > game_boundaries.size().y {
            //     transform.translation.y = max_clamp;
            //     return;
            // }
            
            if min_clamp >= max_clamp {
                transform.translation.y = min_clamp;
                return;
            }

            if player_transform.translation.y
                > transform.translation.y + projection.area.size().y * 0.25
            {
                transform.translation.y = (player_transform.translation.y
                    - projection.area.size().y * 0.25)
                    .clamp(min_clamp, max_clamp);
            } else if player_transform.translation.y < transform.translation.y {
                transform.translation.y =
                    (player_transform.translation.y).clamp(min_clamp, max_clamp);
            }
        });
    });
}