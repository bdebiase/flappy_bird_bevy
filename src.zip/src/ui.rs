use bevy::prelude::*;

use crate::game::GameScore;

#[derive(Component)]
pub struct ScoreText;

pub struct GameUiPlugin;

impl Plugin for GameUiPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Startup, setup).add_systems(Update, update_score.run_if(resource_changed::<GameScore>()));
    }
}

fn setup(
    mut commands: Commands,
) {
    commands.spawn((TextBundle {
        text: Text::from_section("", TextStyle {
            font_size: 64.0,
            ..default()
        }),
        style: Style {
            justify_self: JustifySelf::Center,
            top: Val::Percent(10.0),
            ..default()
        },
        ..default()
    }, ScoreText));
}

fn update_score(
    mut query: Query<&mut Text, With<ScoreText>>,
    game_score: Res<GameScore>,
) {
    query.for_each_mut(|mut text| {
        text.sections.get_mut(0).unwrap().value = game_score.to_string();
    });
}