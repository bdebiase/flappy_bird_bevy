use std::time::Duration;

use bevy::{
    audio::{PlaybackMode, VolumeLevel},
    input::common_conditions::input_just_pressed,
    prelude::*,
};
use bevy_asset_loader::{asset_collection::AssetCollection, loading_state::LoadingStateAppExt};

use crate::{
    game::{GameBoundaries, GameSpeed, GameState, GameScore},
    physics::{Collider, CollisionEvent, Velocity},
    pipes::{Pipe, PipeArea},
};

#[derive(Component, Default)]
pub struct Player;

#[derive(AssetCollection, Resource)]
struct PlayerAssets {
    #[asset(path = "sprites/bird", collection(typed))]
    sprite_folder: Vec<Handle<Image>>,
    #[asset(path = "audio/flap.ogg")]
    flap_audio: Handle<AudioSource>,
    #[asset(path = "audio/hit.ogg")]
    hit_audio: Handle<AudioSource>,
    #[asset(path = "audio/fall.ogg")]
    fall_audio: Handle<AudioSource>,
    #[asset(path = "audio/point.ogg")]
    point_audio: Handle<AudioSource>,
}

#[derive(Component, Default)]
pub struct AnimationIndices {
    first: usize,
    last: usize,
}

#[derive(Component, Default, Deref, DerefMut)]
pub struct AnimationTimer(Timer);

#[derive(Resource)]
pub struct FlapForce(pub f32);

pub struct PlayerPlugin;

impl Plugin for PlayerPlugin {
    fn build(&self, app: &mut App) {
        app.add_collection_to_loading_state::<_, PlayerAssets>(GameState::Loading)
            .insert_resource(FlapForce(150.0))
            .add_systems(OnExit(GameState::Loading), setup)
            .add_systems(OnEnter(GameState::Idling), restart)
            .add_systems(
                Update,
                (
                    handle_death,
                    auto_flap.run_if(in_state(GameState::Idling)),
                    flap_input
                        .run_if(can_flap)
                        .run_if(not(in_state(GameState::Dead))),
                    animate_sprite,
                    animate_velocity,
                    trigger_restart
                        .run_if(in_state(GameState::Dead))
                        .run_if(input_just_pressed(KeyCode::Space)),
                ).chain()
                    .run_if(not(in_state(GameState::Loading))),
            )
            .add_systems(PostUpdate, collisions.run_if(not(in_state(GameState::Loading))));
    }
}

fn setup(
    mut commands: Commands,
    mut texture_atlases: ResMut<Assets<TextureAtlas>>,
    mut textures: ResMut<Assets<Image>>,
    player_assets: Res<PlayerAssets>,
) {
    let mut texture_atlas_builder = TextureAtlasBuilder::default();
    for handle in player_assets.sprite_folder.iter() {
        let id = handle.id();
        let Some(texture) = textures.get(id) else {
            warn!(
                "{:?} did not resolve to an `Image` asset.",
                handle.path().unwrap()
            );
            continue;
        };

        texture_atlas_builder.add_texture(id, texture);
    }

    let texture_atlas = texture_atlas_builder.finish(&mut textures).unwrap();
    let vendor_handle = player_assets.sprite_folder.get(0).unwrap();
    let vendor_index = texture_atlas.get_texture_index(vendor_handle).unwrap();
    let vendor_texture = textures.get(vendor_handle).unwrap();
    let texture_atlas_handle = texture_atlases.add(texture_atlas);

    commands.spawn((
        SpriteSheetBundle {
            sprite: TextureAtlasSprite::new(vendor_index),
            texture_atlas: texture_atlas_handle,
            transform: Transform::from_translation(Vec3::Z * 500.0),
            ..default()
        },
        AnimationIndices { first: 0, last: 2 },
        AnimationTimer(Timer::from_seconds(0.1, TimerMode::Repeating)),
        Velocity::default(),
        Collider {
            size: Vec2::new(vendor_texture.size_f32().y * 0.9, vendor_texture.size_f32().y * 0.8),
        },
        Player,
        Name::from("Player"),
    ));
}

fn handle_death(
    mut commands: Commands,
    mut query: Query<&mut Velocity, With<Player>>,
    mut time: ResMut<Time<Virtual>>,
    mut death_timer: Local<Timer>,
    player_assets: Res<PlayerAssets>,
    game_state: Res<State<GameState>>,
    real_time: Res<Time<Real>>,
) {
    if death_timer.duration() == Duration::from_secs_f32(0.0) {
        death_timer.set_duration(Duration::from_secs_f32(1.0));
    }

    if **game_state != GameState::Dead {
        if !death_timer.paused() {
            println!("RESET TIMER");
            death_timer.pause();
            death_timer.reset();
        }
        return;
    }

    if death_timer.paused() {
        death_timer.unpause();
    }

    if death_timer.percent() == 0.0 {
        println!("JUST DIED");
        query.for_each_mut(|mut velocity| {
            **velocity = Vec2::ZERO;
        });
        time.pause();
        death_timer.reset();

        commands.spawn(AudioSourceBundle {
            source: player_assets.hit_audio.clone(),
            settings: PlaybackSettings {
                mode: PlaybackMode::Remove,
                volume: bevy::audio::Volume::Absolute(VolumeLevel::new(0.1)),
                ..default()
            },
        });
    }

    death_timer.tick(real_time.delta());

    if death_timer.just_finished() {
        time.unpause();

        commands.spawn(AudioSourceBundle {
            source: player_assets.fall_audio.clone(),
            settings: PlaybackSettings {
                mode: PlaybackMode::Remove,
                volume: bevy::audio::Volume::Absolute(VolumeLevel::new(0.1)),
                ..default()
            },
        });
    }
}

fn restart(mut query: Query<&mut Transform, With<Player>>) {
    query.for_each_mut(|mut transform| {
        transform.translation.x = 0.0;
        transform.translation.y = 0.0;
    });
}

fn trigger_restart(mut next_state: ResMut<NextState<GameState>>, time: Res<Time<Virtual>>) {
    if time.is_paused() {
        return;
    }

    next_state.set(GameState::Idling);
}

fn animate_sprite(
    mut query: Query<(
        &mut AnimationTimer,
        &mut TextureAtlasSprite,
        &AnimationIndices,
    )>,
    time: Res<Time>,
) {
    query.for_each_mut(|(mut timer, mut sprite, indices)| {
        timer.tick(time.delta());
        if timer.just_finished() {
            sprite.index = if sprite.index == indices.last {
                indices.first
            } else {
                sprite.index + 1
            };
        }
    });
}

fn can_flap(query: Query<&Transform, With<Player>>, game_boundaries: Res<GameBoundaries>) -> bool {
    for transform in query.iter() {
        if transform.translation.y > game_boundaries.max.y {
            return false;
        }
    }
    return true;
}

fn flap_input(
    mut commands: Commands,
    mut query: Query<&mut Velocity, With<Player>>,
    mut next_state: ResMut<NextState<GameState>>,
    player_assets: Res<PlayerAssets>,
    game_state: Res<State<GameState>>,
    keyboard_input: Res<Input<KeyCode>>,
    flap_force: Res<FlapForce>,
) {
    query.for_each_mut(|mut velocity| {
        if keyboard_input.just_pressed(KeyCode::Space) {
            velocity.y = flap_force.0;

            commands.spawn(AudioSourceBundle {
                source: player_assets.flap_audio.clone(),
                settings: PlaybackSettings {
                    mode: PlaybackMode::Remove,
                    volume: bevy::audio::Volume::Absolute(VolumeLevel::new(0.1)),
                    ..default()
                },
            });

            if *game_state == GameState::Idling {
                next_state.set(GameState::Playing);
            }
        }
    });
}

fn auto_flap(
    mut query: Query<(&mut Velocity, &Transform), With<Player>>,
    flap_force: Res<FlapForce>,
) {
    query.for_each_mut(|(mut velocity, transform)| {
        if transform.translation.y < -0.0 && velocity.y < 0.0 {
            velocity.y = flap_force.0 * 0.5;
        }
    });
}

fn animate_velocity(
    mut query: Query<(&mut Transform, &Velocity), With<Player>>,
    game_state: Res<State<GameState>>,
    game_speed: Res<GameSpeed>,
    time: Res<Time>,
) {
    query.for_each_mut(|(mut transform, velocity)| {
        let rot = match **game_state {
            GameState::Playing => velocity.y.atan2(**game_speed),
            GameState::Dead => -90f32.to_radians(),
            _ => 0.0,
        };
        transform.rotation = transform
            .rotation
            .lerp(Quat::from_rotation_z(rot), 25.0 * time.delta_seconds());
        // let rot = if velocity.y > 0.0 {
        //     30f32.to_radians()
        // } else {
        //     (velocity.y.to_radians() * 0.5).clamp(-90f32.to_radians(), 0.0)
        // };
        // transform.rotation = transform.rotation.lerp(
        //     Quat::from_rotation_z(rot),
        //     25.0 * time.delta_seconds(),
        // );
    });
}

fn collisions(
    mut commands: Commands,
    mut query: Query<(&mut Transform, &mut Velocity, Entity), With<Player>>,
    mut next_state: ResMut<NextState<GameState>>,
    mut collision_events: EventReader<CollisionEvent>,
    mut game_score: ResMut<GameScore>,
    player_assets: Res<PlayerAssets>,
    pipe_query: Query<Entity, With<Pipe>>,
    pipe_area_query: Query<Entity, (With<PipeArea>, Without<Pipe>)>,
    game_state: Res<State<GameState>>,
    game_boundaries: Res<GameBoundaries>,
) {
    query.for_each_mut(|(mut transform, mut velocity, entity)| {
        if transform.translation.y < game_boundaries.min.y {
            **velocity = Vec2::ZERO;
            transform.translation.y = game_boundaries.min.y;
            if *game_state != GameState::Dead {
                next_state.set(GameState::Dead);
            }
        }

        for event in collision_events.read() {
            if event.entity_a == entity {
                if pipe_query.contains(event.entity_b) {
                    if *game_state != GameState::Dead {
                        next_state.set(GameState::Dead);
                        break;
                    }
                } else if pipe_area_query.contains(event.entity_b) {
                    **game_score += 1;

                    commands.entity(event.entity_b).despawn();

                    commands.spawn(AudioSourceBundle {
                        source: player_assets.point_audio.clone(),
                        settings: PlaybackSettings {
                            mode: PlaybackMode::Remove,
                            volume: bevy::audio::Volume::Absolute(VolumeLevel::new(0.1)),
                            ..default()
                        },
                    });
                }
            }
        }
    });
}
